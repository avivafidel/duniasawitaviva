 <!-- Area Chart -->
 <div class="col-xl-12 col-lg-7">
     <div class="card shadow mb-4">
         <!-- Card Header - Dropdown -->
         <div
             class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
             <h6 class="m-0 font-weight-bold text-primary">Form Transaksi Peminjaman</h6>
             <div class="dropdown no-arrow">
                 <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                 </a>
                 <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                     aria-labelledby="dropdownMenuLink">
                     <div class="dropdown-header">Dropdown Header:</div>
                     <a class="dropdown-item" href="#">Action</a>
                     <a class="dropdown-item" href="#">Another action</a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Something else here</a>
                 </div>
             </div>
         </div>
         <!-- Card Body -->
         <div class="card-body">


             <form class="user" method="post" action="">
                 <div class="form-group row">
                     <div class="col-sm-6 mb-3 mb-sm-0">
                         <input type="text" name="idpinjam" required class="form-control form-control-user" id="exampleInputIdPinjam"
                             placeholder="ID Pinjam">
                     </div>
                     <div class="col-sm-6">
                         <input type="text" name="idsupliyer" required class="form-control form-control-user" id="exampleInputIdSupliyer"
                             placeholder="Id Supliyer">
                     </div>
                 </div>
                 <div class="form-group">
                     <input type="text" name="jumlahpinjam" required class="form-control form-control-user" id="exampleInputJumlahPinjam"
                         placeholder="Jumlah Pinjam">
                 </div>
                 </div>
                 <input type="submit" name="simpan" class="btn btn-primary " value="Simpan">
                 <a href="?" class="btn btn-google ">
                     <i class="fab fa-google fa-fw"></i> Batal
                 </a>
             </form>
             <hr>
             <?php
                //Aksi
                if (isset($_POST['simpan'])) {
                    mysqli_query($sambung, "INSERT INTO peminjaman (idpinjam,idsupliyer,jumlahpinjam) 
                     VALUES ('$_POST[idpinjam]', '$_POST[idsupliyer]', '$_POST[jumlahpinjam]',");
                    echo "<script>window.location = ('?page=pinjaman')</script>";
                } else if (isset($_GET['hapus'])) {
                    mysqli_query($sambung, "DELETE FROM peminjaman WHERE idpinjam = '$_GET[hapus]'");
                    echo "<script>window.location = ('?page=pinjaman')</script>";
                }
                ?>
             <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                 <thead>
                     <tr>
                         <th>ID Pinjam</th>
                         <th>ID Supliyer</th>
                         <th>Jumlah Pinjam</th>
                        
                     </tr>
                 </thead>


                 <tbody>
                     <?php
                        $query = mysqli_query($sambung, "SELECT * FROM peminjaman order by idpinjam asc");
                        while ($baca = mysqli_fetch_assoc($query)) {
                        ?>
                         <tr>
                             <td><?php echo $baca['idpinjam']; ?></td>
                             <td><?php echo $baca['idsupliyer']; ?></td>
                             <td><?php echo $baca['jumlahpinjam']; ?></td>
                             <td>
                                 <a class="btn btn-info" href="?page=pinjaman&ubah=<?php echo $baca['idpinjam']; ?>">
                                     <i class="fa fa-edit"></i></a>
                                 <a class="btn btn-info" href="?page=pinjaman&cetak=<?php echo $baca['idpinjam']; ?>">
                                     <i class="fa fa-print"></i></a>
                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>
