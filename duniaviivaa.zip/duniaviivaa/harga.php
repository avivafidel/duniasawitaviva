<?php
// Include file koneksi
include 'koneksi.php';

// Inisialisasi variabel kosong untuk form
$hargabuah = "";
$tanggal = "";

// Cek jika ada data POST dari form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mengambil data dari form dan membersihkan input
    $hargabuah = $sambung->real_escape_string($_POST['hargabuah']);
    $tanggal = $sambung->real_escape_string($_POST['tanggal']);

    // Query untuk insert data ke dalam database
    $sql = "INSERT INTO harga (hargabuah, tanggal) VALUES ('$hargabuah', '$tanggal')";

    // Eksekusi query
    if ($sambung->query($sql) === TRUE) {
        echo "<div class='alert alert-success'>Data berhasil disimpan!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $sambung->error . "</div>";
    }
}

// Jika ada parameter ID di URL, ambil data untuk di-edit
if (isset($_GET['idharga'])) {
    $idharga = $sambung->real_escape_string($_GET['idharga']);
    $query = "SELECT * FROM harga WHERE idharga='$idharga'";
    $result = $sambung->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hargabuah = $row['hargabuah'];
        $tanggal = $row['tanggal'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Harga Buah</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Form Harga Buah</h2>
    <form action="harga.php" method="POST">
         <!-- Input ID Buah -->
         <div class="form-group">
            <label for="idharga">ID Harga:</label>
            <input type="number" name="idbuah" id="idharga" class="form-control" value="<?php echo $idharga; ?>" required>
        </div>
        <!-- Input Harga Buah -->
        <div class="form-group">
            <label for="hargabuah">Harga Buah:</label>
            <input type="number" name="hargabuah" id="hargabuah" class="form-control" value="<?php echo $hargabuah; ?>" required>
        </div>

        <!-- Input Tanggal -->
        <div class="form-group">
            <label for="tanggal">Tanggal:</label>
            <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo $tanggal; ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="harga.php" class="btn btn-secondary">Reset</a>
    </form>

    <h3 class="mt-5">Daftar Harga Buah</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Harga Buah</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Query untuk mengambil data harga buah yang ada
        $query = "SELECT * FROM harga ORDER BY tanggal DESC";
        $result = $sambung->query($query);
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['idharga'] . "</td>";
            echo "<td>Rp " . number_format($row['hargabuah'], 0, ',', '.') . "</td>";
            // Format tanggal menjadi DD-MM-YYYY
            echo "<td>" . date("d-m-Y", strtotime($row['tanggal'])) . "</td>";
            echo "<td>
                    <a href='harga.php?idharga=" . $row['idharga'] . "' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='hapus_harga.php?idharga=" . $row['idharga'] . "' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
