<?php
// Include file koneksi
include 'koneksi.php';

// Inisialisasi variabel kosong untuk form
$nama = "";
$email = "";
$subject = "";
$isipesan = "";
$tanggal = date("Y-m-d H:i:s"); // Menyimpan tanggal saat pesan dikirim

// Cek jika ada data POST dari form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mengambil data dari form
    $nama = $sambung->real_escape_string($_POST['nama']);
    $email = $sambung->real_escape_string($_POST['email']);
    $subject = $sambung->real_escape_string($_POST['subject']);
    $isipesan = $sambung->real_escape_string($_POST['message']);

    // Query untuk memasukkan data pesan ke dalam tabel
    $sql = "INSERT INTO pesan (nama, email, subject, isipesan, tanggal) VALUES ('$nama', '$email', '$subject', '$isipesan', '$tanggal')";

    // Menjalankan query dan cek apakah berhasil
    if ($sambung->query($sql) === TRUE) {
        $success_message = "Pesan Anda telah terkirim. Terima kasih!";
    } else {
        $error_message = "Terjadi kesalahan: " . $sambung->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Kontak</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Form Kontak</h2>

    <!-- Menampilkan pesan sukses atau error -->
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php elseif (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Form untuk mengirim pesan -->
    <form action="BootsRahman/forms/contact.php" method="POST">
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="subject">Subjek:</label>
            <input type="text" name="subject" id="subject" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="message">Pesan:</label>
            <textarea name="message" id="message" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
    </form>

    <h3 class="mt-5">Pesan yang Diterima</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Subjek</th>
                <th>Isi Pesan</th> <!-- Kolom baru untuk menampilkan isi pesan -->
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query untuk mengambil data pesan dari tabel
            $query = "SELECT * FROM pesan ORDER BY tanggal DESC";
            $result = $sambung->query($query);

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['idpesan'] . "</td>";
                echo "<td>" . $row['nama'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['subject'] . "</td>";
                // Menampilkan isi pesan, menggunakan nl2br untuk menambahkan baris baru jika ada
                echo "<td>" . nl2br(htmlspecialchars($row['isipesan'])) . "</td>";
                // Format tanggal menjadi DD-MM-YYYY HH:MM:SS
                echo "<td>" . date("d-m-Y H:i:s", strtotime($row['tanggal'])) . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
