<!-- Area Chart -->
<script>
     function sum() {
         var txtFirstNumberValue = document.getElementById('brutoid').value;
         var txtSecondNumberValue = document.getElementById('tarraid').value;
         var resultneto = parseInt(txtFirstNumberValue) - parseInt(txtSecondNumberValue);
         var rtpotongan = resultneto * 0.04;
         var rnetobersih = resultneto - rtpotongan;
         if (!isNaN(resultneto)) {
             document.getElementById('nettoid').value = resultneto;
             document.getElementById('potonganid').value = rtpotongan;
             document.getElementById('netberid').value = rnetobersih;
         } else {
             document.getElementById('nettoid').value = 0;
             document.getElementById('potonganid').value = 0;
             document.getElementById('netberid').value = 0;
         }
     }

     function totalbayar() {
         var harga = document.getElementById('hargaid').value;
         var netbersih = document.getElementById('netberid').value;
         var bayar = parseInt(harga) * parseInt(netbersih);
         if (!isNaN(bayar)) {
             document.getElementById('bayarid').value = bayar;
         } else {
             document.getElementById('bayarid').value = bayar;
         }
     }
 </script>
 <div class="col-xl-12 col-lg-7">
     <div class="card shadow mb-4">
         <!-- Card Header - Dropdown -->
         <div
             class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
             <h6 class="m-0 font-weight-bold text-primary">Form Transkasi Pembelian TBS</h6>
             <div class="dropdown no-arrow">
                 <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                 </a>

             </div>
         </div>
         <!-- Card Body -->
         <div class="card-body">
             <?php
                date_default_timezone_set('Asia/Jakarta');

                ?>

             <form class="user" method="post" action="">
                 <?php if (isset($_GET["proses"])) {
                        $cari = mysqli_query($sambung, "SELECT * FROM pembelian where idbeli='$_GET[proses]'");
                        $c = mysqli_fetch_array($cari);
                    ?>
                     <div class="form-group row">
                         <div class="col-sm-3 mb-3 mb-sm-0">
                             <input type="text" required class="form-control"
                                 name="idbeli" value="<?php echo $c['idbeli']; ?>" readonly>
                         </div>
                         <div class="col-sm-3 mb-3 mb-sm-0">
                             <select name="idsupliyer" class="form-control" readonly>

                                 <?php
                                    $tampil = mysqli_query($sambung, "SELECT * FROM supliyer where idsupliyer='$c[idsupliyer]'");
                                    while ($w = mysqli_fetch_array($tampil)) { ?>
                                     <option value="<?php echo $w['idsupliyer']; ?>"><?php echo $w['namasupliyer']; ?></option>
                                 <?php } ?>
                             </select>
                         </div>
                         <div class="col-sm-3">
                             <select name="idsupir" class="form-control" readonly>

                                 <?php
                                    $tampil = mysqli_query($sambung, "SELECT * FROM supirr where idsupir='$c[idsupir]'");
                                    while ($w = mysqli_fetch_array($tampil)) { ?>
                                     <option value="<?php echo $w['idsupir']; ?>"><?php echo $w['namasupir']; ?></option>
                                 <?php } ?>
                             </select>
                         </div>
                         <div class="col-sm-3">

                             <input type="text" name="jammasuk" required class="form-control" id="exampleLastName" readonly value="<?php echo date('d-m-Y H:i:s'); ?>"
                                 placeholder="Tanggal">
                         </div>
                     </div>

                     <div class="form-group row">
                         <div class="col-sm-4 mb-3 mb-sm-0">
                             <input type="text" required class="form-control"
                                 name="bruto" id="brutoid" placeholder="Bruto" value="<?php echo $c['bruto']; ?>" readonly>
                         </div>

                     <?PHP } else { ?>
                         <div class="form-group row">
                             <div class="col-sm-3 mb-3 mb-sm-0">
                                 <input type="text" required class="form-control"
                                     name="idbeli" placeholder="NP001">
                             </div>
                             <div class="col-sm-3 mb-3 mb-sm-0">
                                 <select name="idsupliyer" class="form-control">
                                     <option value="">Pilih Supliyer</option>
                                     <?php
                                        $tampil = mysqli_query($sambung, "SELECT * FROM supliyer");
                                        while ($w = mysqli_fetch_array($tampil)) { ?>
                                         <option value="<?php echo $w['idsupliyer']; ?>"><?php echo $w['namasupliyer']; ?></option>
                                     <?php } ?>
                                 </select>
                             </div>
                             <div class="col-sm-3">
                                 <select name="idsupir" class="form-control">
                                     <option value="">Pilih Supir</option>
                                     <?php
                                        $tampil = mysqli_query($sambung, "SELECT * FROM supirr");
                                        while ($w = mysqli_fetch_array($tampil)) { ?>
                                         <option value="<?php echo $w['idsupir']; ?>"><?php echo $w['namasupir']; ?></option>
                                     <?php } ?>
                                 </select>
                             </div>
                             <div class="col-sm-3">

                                 <input type="text" name="jammasuk" required class="form-control" id="exampleLastName" readonly value="<?php echo date('d-m-Y H:i:s'); ?>"
                                     placeholder="Tanggal">
                             </div>
                         </div>

                         <div class="form-group row">
                             <div class="col-sm-4 mb-3 mb-sm-0">
                                 <input type="text" required class="form-control"
                                     name="bruto" id="brutoid" placeholder="Bruto">
                             </div>


                             <input type="submit" name="simpan" class="btn btn-primary " value="Proses">
                         <?php } ?>
                         </div>
                         <?php if (isset($_GET["proses"])) { ?>
                             <div class="form-group row">
                                 <div class="col-sm-4">
                                     <input type="text" required class="form-control"
                                         name="tarra" id="tarraid" onkeyup="sum();" placeholder="Tarra">
                                 </div>
                                 <div class="col-sm-4">
                                     <input type="text" required class="form-control"
                                         name="netto" id="nettoid" placeholder="Netto" readonly>
                                 </div>
                                 <div class="col-sm-4 mb-3 mb-sm-0">
                                     <input type="text" required class="form-control"
                                         id="potonganid" name="potongan" placeholder="Potongan" readonly>
                                 </div>
                             </div>

                             <div class="form-group row">


                                 <div class="col-sm-4 mb-3 mb-sm-0">
                                     <input type="text" required class="form-control"
                                         id="netberid" name="netber" placeholder="Netto Bersih" readonly>
                                 </div>
                                 <div class="col-sm-4 mb-3 mb-sm-0">
                                     <input type="text" required class="form-control"
                                         id="hargaid" name="harga" onkeyup="totalbayar();" placeholder="Harga">
                                 </div>
                                 <div class="col-sm-4 mb-3 mb-sm-0">
                                     <input type="text" required class="form-control"
                                         id="bayarid" name="bayar" placeholder="Total Bayar" readonly>
                                 </div>
                             </div>
                             <input type="submit" name="update" class="btn btn-primary " value="Simpan">

                             <a href="?page=pembelian" class="btn btn-google ">
                                 <i class="fab fa-google fa-fw"></i> Batal
                             </a>
                         <?php } ?>
             </form>
             <hr>
             <?php
                //Aksi
                if (isset($_POST['simpan'])) {
                    mysqli_query($sambung, "INSERT INTO pembelian (idbeli,idsupliyer,idsupir,jammasuk,bruto) 
                     VALUES ('$_POST[idbeli]','$_POST[idsupliyer]', '$_POST[idsupir]', now(),'$_POST[bruto]')");
                    $id = $_POST['idbeli'];
                    echo "<script>window.location = ('?page=pembelian&proses=$id')</script>";
                } else if (isset($_POST['update'])) {
                    mysqli_query($sambung, "UPDATE pembelian set tarra='$_POST[tarra]',netto='$_POST[netto]', nettobersih='$_POST[netber]',
                    potongan= '$_POST[potongan]',jamkeluar=now(),harga='$_POST[harga]' where idbeli='$_POST[idbeli]'");

                    echo "<script>window.location = ('?page=pembelian')</script>";
                }
                ?>


             <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                 <thead>
                     <tr>
                         <th>No Faktur </th>
                         <th>Nama Supliyer</th>
                         <th>Bruto</th>
                         <th>Tarra</th>
                         <th>Netto</th>
                         <th>Netto Bersih</th>
                         <th>Harga</th>
                         <th>Dibayarkan</th>
                         <th>Aksi</th>
                     </tr>
                 </thead>

                 <tbody>
                     <?php

                        $query = mysqli_query($sambung, "SELECT * FROM transaksii as p inner join supliyer as s on
                        p.idsupliyer=s.idsupliyer order by p.jammasuk desc");

                        while ($baca = mysqli_fetch_assoc($query)) {
                        ?>
                         <tr>
                             <td><?php echo $baca['idbeli']; ?></td>
                             <td><?php echo $baca['namasupliyer']; ?></td>
                             <td><?php echo $baca['bruto']; ?></td>
                             <td><?php echo $baca['tarra']; ?></td>
                             <td><?php echo $baca['netto']; ?></td>
                             <td><?php echo $baca['nettobersih']; ?></td>
                             <td><?php echo $baca['harga']; ?></td>
                             <td><?php $bayar = $baca["nettobersih"] * $baca["harga"];
                                    echo "Rp " . number_format($bayar, 0, ",", "."); ?></td>
                             <td>
                                 <a class="btn btn-info" href="?page=pembelian&ubah=<?php echo $baca['idbeli']; ?>">
                                     <i class="fa fa-info"></i></a>
                                 <a class="btn btn-info" href="?page=pembelian&cetak=<?php echo $baca['idbeli']; ?>">
                                     <i class="fa fa-print"></i></a>

                             </td>
                         </tr>
                     <?php } ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>