<?php
// Include file koneksi
include 'koneksi.php';

// Cek apakah parameter 'idharga' ada di URL
if (isset($_GET['idharga'])) {
    // Ambil nilai 'idharga' dari URL dan bersihkan input untuk keamanan
    $idharga = $sambung->real_escape_string($_GET['idharga']);

    // Query untuk menghapus data harga berdasarkan ID
    $sql = "DELETE FROM harga WHERE idharga='$idharga'";

    // Eksekusi query
    if ($sambung->query($sql) === TRUE) {
        // Jika berhasil dihapus, redirect kembali ke halaman harga.php dengan pesan sukses
        header("Location: harga.php?status=success");
        exit;
    } else {
        // Jika ada error, redirect dengan pesan error
        header("Location: harga.php?status=error");
        exit;
    }
} else {
    // Jika 'idharga' tidak ditemukan di URL, redirect kembali ke halaman harga.php dengan pesan error
    header("Location: harga.php?status=error");
    exit;
}

// Tutup koneksi
$sambung->close();
?>
